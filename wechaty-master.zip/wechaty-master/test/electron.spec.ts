/**
 * Wechaty - Wechat for Bot. Connecting ChatBots
 *
 * Licenst: ISC
 * https://github.com/wechaty/wechaty
 *
 */
import { test } from 'ava'

test('Electron smoke testing', async t => {
  t.true(true, 'test')
})

test.skip('Electron open wx', t => {
  t.pass('ok')
})
