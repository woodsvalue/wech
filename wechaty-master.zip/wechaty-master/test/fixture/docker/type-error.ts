let i = 3
i = "should set to string because it's type is number"
console.log(i)
