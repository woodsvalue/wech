const { Wechaty } = require('wechaty')

const bot = Wechaty.instance()                                                                                                               
console.log(bot.version())
