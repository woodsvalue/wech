import { Brolog } from 'brolog'

const brolog = new Brolog()
brolog.info('OK', 'with-import.ts')
