const { NotExist } = require('not-exist-at-all-fasdfasdsfaf')

const ne = new NowExist()
console.log(ne) // should not run to here
