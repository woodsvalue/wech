import { NotExist } from 'not-exist-at-all-fdsafasdfafsad'

const ne = new NotExist()
console.log(ne) // should not run to here
