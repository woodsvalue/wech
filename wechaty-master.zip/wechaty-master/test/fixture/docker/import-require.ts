import fs = require('fs')

fs.statSync('/')
console.log('OK')
