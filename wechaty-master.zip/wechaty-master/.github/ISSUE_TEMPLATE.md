### Run `npm run doctor` or `wechaty run doctor`(for docker user), paste output here 



### Expected behavior



### Actual behavior



### Steps to reproduce the behavior (and fixes, if any)



### Paste the full output logs here with `WECHATY_LOG=silly` set


